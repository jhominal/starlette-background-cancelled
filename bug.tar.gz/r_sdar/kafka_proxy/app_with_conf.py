import logging.config

from r_sdar.kafka_proxy.app import create_application
from r_sdar.kafka_proxy.lib.kafka_producer_settings import KafkaProducerSettings


_logging_config = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'simple': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'stream': 'ext://sys.stdout',
            'formatter': 'simple',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'r_sdar': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}
logging.config.dictConfig(_logging_config)
kafka_producer_settings = KafkaProducerSettings(
    config={},
    poll_interval_s=1,
)
application = create_application(kafka_producer_settings)
