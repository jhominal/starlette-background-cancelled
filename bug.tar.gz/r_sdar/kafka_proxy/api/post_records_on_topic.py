import logging
from typing import Optional, Dict, Any, List, Awaitable

from ..lib.mock_kafka import KafkaException
from fastapi import Body, Depends
from pydantic import BaseModel  # pylint: disable=no-name-in-module
from starlette.background import BackgroundTasks

from r_sdar.kafka_proxy.lib.async_kafka import AsyncProducer

logger = logging.getLogger(__name__)


async def process_delivery(produce_future: Awaitable[None]) -> None:
    try:
        await produce_future
        logger.info("Message was successfully delivered")
    except KafkaException:
        logger.exception("An error occurred while delivering a message")
    except Exception:
        logger.exception("Unexpected error")
        raise


class Record(BaseModel):
    value: Optional[Dict[str, Any]] = {}


async def post_records_on_topic(
        *,
        producer: AsyncProducer = Depends(),
        topic_id: str,
        records: List[Record] = Body(..., embed=True),
        background_tasks: BackgroundTasks,
):
    for record in records:
        try:
            produce_future = producer.produce(
                topic=topic_id,
                value=record.json().encode(encoding='utf-8'),
            )
            background_tasks.add_task(process_delivery, produce_future=produce_future)
        except KafkaException:
            logger.exception("An error occurred while producing a message")
            raise
