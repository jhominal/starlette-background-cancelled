from fastapi import FastAPI
from starlette import status
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response

from r_sdar.kafka_proxy.api.post_records_on_topic import post_records_on_topic
from r_sdar.kafka_proxy.lib.async_kafka import AsyncProducer
from r_sdar.kafka_proxy.lib.kafka_producer_settings import KafkaProducerSettings
from r_sdar.kafka_proxy.lib.log_request_middleware import log_request


def create_application(kafka_producer_settings: KafkaProducerSettings):
    application = FastAPI(
        middleware=[
            Middleware(BaseHTTPMiddleware, dispatch=log_request),
        ],
    )

    # HACK: Waiting for lifetime-scoped dependencies in FastAPI (https://github.com/tiangolo/fastapi/issues/617)
    producer = None
    application.dependency_overrides[AsyncProducer] = lambda: producer

    @application.on_event("startup")
    async def start_producer():
        nonlocal producer
        producer = AsyncProducer(
            config=kafka_producer_settings.config,
            poll_interval_s=kafka_producer_settings.poll_interval_s,
        )
        await producer.startup()

    @application.on_event("shutdown")
    async def shutdown_producer():
        await producer.flush()
        await producer.shutdown()

    application.post("/kafka-proxy/topics/{topic_id}", status_code=status.HTTP_202_ACCEPTED, response_class=Response)(post_records_on_topic)

    return application

