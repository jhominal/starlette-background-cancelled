import logging
import time
from typing import Awaitable, Callable

from fastapi.exception_handlers import http_exception_handler
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger(__name__)


async def log_request(request: Request, call_next: Callable[[Request], Awaitable[Response]]):
    start_time = time.time()
    response = None
    try:
        response = await call_next(request)
    except HTTPException as exc:
        response = await http_exception_handler(request, exc)
    except (Exception,):  # pylint: disable=broad-except
        logger.exception(
            msg="Uncaught exception"
        )
        response = Response(status_code=500)
    finally:
        logger.info(
            "Processed HTTP Request %s %s %s %s",
            request.method,
            request.url.path,
            response.status_code,
            int((time.time() - start_time) * 1000),
        )
    return response
