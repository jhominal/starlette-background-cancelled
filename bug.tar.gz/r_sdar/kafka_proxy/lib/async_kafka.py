from __future__ import generator_stop

from typing import Any, Awaitable, Dict, NoReturn, Optional

import anyio
import anyio.abc
from anyio import TASK_STATUS_IGNORED
from anyio.abc import TaskStatus

from . import mock_kafka


class _ProduceAwaiter(object):
    """
    This class materializes the infrastructure for awaiting the delivery of a produce operation.
    """

    # Using __slots__ to avoid creation of a new dict for every instance of _ProduceAwaiter
    __slots__ = ["_event", "_error", "_message"]

    _event: anyio.Event
    _error: Optional[mock_kafka.KafkaError]
    _message: Optional[mock_kafka.Message]

    def __init__(self) -> None:
        self._event = anyio.Event()

    def set_result(self, err: Optional[mock_kafka.KafkaError], msg: mock_kafka.Message) -> None:
        self._error = err
        self._message = msg
        self._event.set()

    async def wait_and_raise_on_error(self) -> None:
        await self._event.wait()
        if self._error is not None:
            raise mock_kafka.ProduceError(self._error)


class AsyncProducer(object):
    """
    This class wraps confluent_kafka.Producer in order to make it easier to use in a Python async/await world.

    This class implements:
     * Asynchronous context manager to set up periodic polling of confluent_kafka.Producer
     * Async-friendly flush() and produce() methods, using AnyIO

    Non-goals:
     * Features of confluent_kafka.Producer that we do not currently use (transactions, produce with key/partition/etc.)
     * Hiding/Replacement of confluent_kafka types (Message/KafkaError/etc.)
    """
    _producer: mock_kafka.Producer
    _poll_interval_s: float
    _polling_task_group: Optional[anyio.abc.TaskGroup]

    def __init__(self, *, config: Dict[str, Any], poll_interval_s: float) -> None:
        """
        Instantiate an instance of AsyncProducer, with the given config dictionary and poll frequency.

        :param config: The config dictionary that will be used for kafka_confluent.Producer
        :param poll_interval_s: The interval, in seconds, between two calls to kafka_confluent.Producer.poll()
        """
        self._producer = mock_kafka.Producer(config)
        self._poll_interval_s = poll_interval_s
        self._polling_task_group = None

    @property
    def started(self) -> bool:
        return self._polling_task_group is not None

    async def _poll_producer(self, *, task_status: TaskStatus = TASK_STATUS_IGNORED) -> NoReturn:
        task_status.started()
        while True:
            await anyio.sleep(delay=self._poll_interval_s)
            self._producer.poll(timeout=0)

    async def startup(self) -> None:
        """
        Starts up periodic polling of the underlying kafka_confluent.Producer instance.

        This method exists because the author dislikes direct calls to dunder methods such as __aenter__ and __aexit__.
        """
        if self.started:
            raise RuntimeError("Cannot call startup() if the producer is already started.")

        self._polling_task_group = anyio.create_task_group()
        await self._polling_task_group.__aenter__()
        await self._polling_task_group.start(self._poll_producer)

    async def shutdown(self, *, exc_type=None, exc_val=None, exc_tb=None) -> None:
        """
        Shuts down periodic polling of the underlying kafka_confluent.Producer instance.

        This method exists because the author dislikes direct calls to dunder methods such as __aenter__ and __aexit__.
        """
        if not self.started:
            raise RuntimeError("Cannot call shutdown() if the producer is not started.")

        # anyio DeprecatedAwaitable: had to be awaited in AnyIO 2.x, but not in AnyIO 3.x+
        # Cf. https://anyio.readthedocs.io/en/stable/migration.html#asynchronous-functions-converted-to-synchronous
        # noinspection PyAsyncCall
        self._polling_task_group.cancel_scope.cancel()
        await self._polling_task_group.__aexit__(exc_type, exc_val, exc_tb)
        self._polling_task_group = None

    async def flush(self) -> None:
        """
        Wait asynchronously until there are no more messages in the producer queue.
        """
        if not self.started:
            raise RuntimeError("Cannot call flush() if the producer is not started.")

        # Documentation of Producer.flush indicates that it simply calls "poll" until len() equals 0
        # We do not need to call producer.poll() here as it is called in _poll_producer
        while len(self._producer) != 0:
            await anyio.sleep(delay=self._poll_interval_s)

    async def __aenter__(self) -> 'AsyncProducer':
        await self.startup()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.shutdown(exc_type=exc_type, exc_val=exc_val, exc_tb=exc_tb)

    def produce(self, *, topic: str, value: bytes) -> Awaitable[None]:
        """
        Produce a value to a topic on the current producer, and returns an awaitable object for delivery.

        :param topic: The topic name
        :param value: The value, as a byte string
        :return: An awaitable object that will resolve when the value is delivered, or if it fails delivery.
        :raises confluent_kafka.ProduceError: In case delivery fails, this error will be raised when waiting the return
                value.
        :raises confluent_kafka.KafkaException: In case of an error on the underlying "produce" call, the exception
                will be raised immediately.
        """
        if not self.started:
            raise RuntimeError("Cannot call produce() if the producer is not started.")

        awaiter = _ProduceAwaiter()
        self._producer.produce(topic=topic, value=value, on_delivery=awaiter.set_result)

        # Q: Why not mark produce as async, and use await when calling 'wait_and_raise_on_error'?
        # A: If we mark produce as async, the errors in _producer.produce will be raised only in the await.
        #    However, we would like errors raised synchronously by _producer.produce to be raised immediately.
        #    We can get that result by delegating the post-wait logic in another method.
        return awaiter.wait_and_raise_on_error()
