import time
from collections import defaultdict
from typing import Dict, Any, Callable, Optional


class KafkaError(object):
    pass


class Message(object):
    pass


class KafkaException(Exception):
    pass


class ProduceError(KafkaException):
    pass


class Producer(object):
    def __init__(self, config: Dict[str, Any], delay_s: float = 3):
        self._queued_callbacks = defaultdict(list)
        self._delay_s = delay_s

    def __len__(self):
        return len(self._queued_callbacks)

    def produce(self, topic: str, value: bytes, on_delivery: Callable[[Optional[KafkaError], Message], None]):
        self._queued_callbacks[time.time() + self._delay_s].append(on_delivery)

    def poll(self, timeout: float):
        time.sleep(timeout)
        to_remove = []
        for trigger_time, callbacks in self._queued_callbacks.items():
            if trigger_time < time.time():
                to_remove.append(trigger_time)
                for c in callbacks:
                    c(None, object())
        for k in to_remove:
            del self._queued_callbacks[k]
