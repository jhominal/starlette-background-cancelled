from typing import Dict

from pydantic import BaseModel # pylint: disable=no-name-in-module


class KafkaProducerSettings(BaseModel):
    config: Dict[str, str]
    poll_interval_s: float
